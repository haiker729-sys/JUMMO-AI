package com.merajsir.jummo.security

/** Publisher identity for this JUMMO build. */
object DeveloperInfo {
    const val DEVELOPER_NAME = "Meraj Sir"
    const val COPYRIGHT_YEAR = "2026"
    const val COPYRIGHT_NOTICE = "Copyright © 2026 Meraj Sir. JUMMO."
    const val GITHUB_URL = ""
    const val LICENSE = ""
    const val LICENSE_DETAIL = ""
    const val APP_OFFICIAL_ID = "com.merajsir.jummo"
    const val VERIFIED_DEVELOPER = "Meraj Sir"
}
