package com.merajsir.jummo.background

/**
 * Backward-compatible names used by existing UI and automation components.
 * The implementation and manifest use the JUMMO-branded service names.
 */
typealias JarvisConversationService = JUMMOConversationService
typealias JarvisLiveError = JUMMOLiveError
