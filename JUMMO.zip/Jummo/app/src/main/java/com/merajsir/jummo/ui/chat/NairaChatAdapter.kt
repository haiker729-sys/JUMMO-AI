package com.merajsir.jummo.ui.chat

/**
 * Backward compatibility alias for JarvisChatAdapter
 */
typealias NairaChatAdapter = JarvisChatAdapter
