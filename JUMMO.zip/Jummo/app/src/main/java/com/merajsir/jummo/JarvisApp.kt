package com.merajsir.jummo

/** Compatibility alias for upstream source files that still use the original application class name. */
typealias JarvisApp = JUMMOApp
