package com.merajsir.jummo.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.merajsir.jummo.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        com.merajsir.jummo.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<android.view.View>(R.id.settingsContainer)?.let {
            com.merajsir.jummo.util.ThemeManager.applyDynamicBackground(it)
        }
    }
}
