# JUMMO build notes

The project now includes root Gradle settings/build files, AndroidX Gradle properties, a JDK 17 GitHub Actions workflow, the JUMMO application ID/namespace, and the missing JUMMOApp application class alignment.

## Build
- Debug/installable APK: `./gradlew clean assembleDebug`
- Release APK: `./gradlew assembleRelease` (unsigned unless release signing inputs are supplied)

## Release signing
Set `JUMMO_RELEASE_STORE_FILE`, `JUMMO_RELEASE_STORE_PASSWORD`, `JUMMO_RELEASE_KEY_ALIAS`, and `JUMMO_RELEASE_KEY_PASSWORD` to sign a release build. Set `JUMMO_RELEASE_CERT_SHA256` to enable the app's pinned-certificate trust check. Never commit keystores or passwords.

A successful GitHub Actions run is still required to confirm compilation against the hosted Android SDK.
